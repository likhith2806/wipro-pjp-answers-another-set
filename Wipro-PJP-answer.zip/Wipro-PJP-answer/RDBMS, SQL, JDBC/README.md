# Assignment Questions

![Screenshot (629)](https://user-images.githubusercontent.com/70385488/167589181-d797744f-9394-4bf6-b2b7-6be461bef116.png)
![Screenshot (630)](https://user-images.githubusercontent.com/70385488/167589186-95a3f40c-7395-47da-899b-1831530b7ae1.png)
![Screenshot (631)](https://user-images.githubusercontent.com/70385488/167589188-a9732cdc-f2be-4835-ab29-117357fdca0c.png)
![Screenshot (632)](https://user-images.githubusercontent.com/70385488/167589191-f58ecca7-3911-4108-8e52-99409e56ba30.png)
![Screenshot (633)](https://user-images.githubusercontent.com/70385488/167589193-3d7f5d01-828b-4ef3-8749-534100dd1222.png)
![Screenshot (634)](https://user-images.githubusercontent.com/70385488/167589199-eb03e81d-1e53-48e5-881c-8f77acb9a85a.png)
![Screenshot (635)](https://user-images.githubusercontent.com/70385488/167589202-a501c260-ee48-4fba-88b2-10d937bddd1b.png)
![Screenshot (636)](https://user-images.githubusercontent.com/70385488/167589205-878765bd-0b2a-4815-b011-06fa6bf05c7b.png)
![Screenshot (637)](https://user-images.githubusercontent.com/70385488/164990482-b7fc8020-f39d-4acc-8ef7-a020031e94e4.png)
![Screenshot (638)](https://user-images.githubusercontent.com/70385488/164990522-8d2e219d-b0ac-4e37-86ef-f58cbd6b038d.png)
![Screenshot (639)](https://user-images.githubusercontent.com/70385488/164990524-6c4e7cd3-abd9-4428-8d74-fae34cf95731.png)
![Screenshot (640)](https://user-images.githubusercontent.com/70385488/164990525-92299917-f863-4789-9502-4ec75adb1972.png)
![Screenshot (641)](https://user-images.githubusercontent.com/70385488/164990527-bcbd79d6-9b67-477b-9b9e-279a8460ce3b.png)
![Screenshot (642)](https://user-images.githubusercontent.com/70385488/164990528-690bbd63-fea6-4db9-9ac5-42e8dc7da2c9.png)

# Mini Project 

![Screenshot (643)](https://user-images.githubusercontent.com/70385488/167590763-5e82ef73-5a60-4911-a9af-44cdf208bbca.png)
![Screenshot (644)](https://user-images.githubusercontent.com/70385488/167590774-126c700d-d245-4b87-975d-2a1bf96a214b.png)
![Screenshot (645)](https://user-images.githubusercontent.com/70385488/167590775-516f8ba2-fc88-48d6-897a-81f6b65de198.png)
![Screenshot (646)](https://user-images.githubusercontent.com/70385488/167590779-5c71a3fe-07b2-4093-bfdd-b037a4f2ce33.png)
![Screenshot (647)](https://user-images.githubusercontent.com/70385488/167590782-d3ef26f9-01de-424f-94af-b7a96ae46d95.png)
![Screenshot (648)](https://user-images.githubusercontent.com/70385488/167590798-ffe0e421-ae79-49b3-a357-26da31ad5ce9.png)

