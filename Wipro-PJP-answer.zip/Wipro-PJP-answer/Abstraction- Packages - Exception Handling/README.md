# Assignment Questions
![Screenshot (574)](https://user-images.githubusercontent.com/70385488/167264746-1b679c7e-53db-4ffc-b173-d042b8c2ca57.png)
![Screenshot (575)](https://user-images.githubusercontent.com/70385488/167264747-992f5c08-9fa4-453a-bf54-08acaf839b30.png)
![Screenshot (576)](https://user-images.githubusercontent.com/70385488/167264749-cbb83faa-6b57-444c-a2be-2446e64fc838.png)
![Screenshot (577)](https://user-images.githubusercontent.com/70385488/167264750-7e6fff45-0ccc-4bce-bf3c-235fc80e46f9.png)
![Screenshot (578)](https://user-images.githubusercontent.com/70385488/167264751-e2741547-9a65-4245-832d-842a8737cba7.png)
![Screenshot (579)](https://user-images.githubusercontent.com/70385488/167264752-2e72569f-4a1b-46e0-908e-df5853cd1633.png)
![Screenshot (580)](https://user-images.githubusercontent.com/70385488/167264753-55f0d032-c901-4c70-9593-62d39074baea.png)

# Project Description
![Screenshot (596)](https://user-images.githubusercontent.com/70385488/167264755-117c74f8-eeb7-40f8-88e1-369e054e8d75.png) 
![Screenshot (597)](https://user-images.githubusercontent.com/70385488/167264756-330ad33b-a93e-43bc-8e17-01f08e29e8e2.png)
![Screenshot (598)](https://user-images.githubusercontent.com/70385488/167264758-14591ef3-6fc0-4062-8864-5290c3d85241.png)
![Screenshot (599)](https://user-images.githubusercontent.com/70385488/167264759-bef6762c-3344-42a4-bfcd-0bdbdd7d830d.png)
![Screenshot (600)](https://user-images.githubusercontent.com/70385488/167264761-1ee45269-52d2-4645-9def-521104c12117.png)
![Screenshot (601)](https://user-images.githubusercontent.com/70385488/167264763-60ab2abd-cc8a-4d3e-a97c-45a99775bc4b.png)
![Screenshot (602)](https://user-images.githubusercontent.com/70385488/167264742-4a955105-93d4-4ed0-bb8f-c1bcb68082ba.png)
![Screenshot (603)](https://user-images.githubusercontent.com/70385488/167264743-dacab354-5a89-4f2b-a878-2df9aae5bc45.png)
![Screenshot (604)](https://user-images.githubusercontent.com/70385488/167264744-b63dcc5d-84b8-44c3-86e7-36266bd64874.png)

