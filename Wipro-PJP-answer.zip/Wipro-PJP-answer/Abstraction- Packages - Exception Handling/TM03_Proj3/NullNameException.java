package com.mile1.exception;

public class NullNameException extends Exception {
	public String toString()  
	{
		return "Name is null";
	}
}
