public class Q_4 {
    public static void main(String args[]) {
        int[] arr = {92,78,54,12,56,46,94,75,45,78,95,78,96};
        for (int i=0; i<arr.length; i++) {
            System.out.print((char)arr[i] + ", ");
        }
    }
}
